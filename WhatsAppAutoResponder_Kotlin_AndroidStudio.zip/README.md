# WhatsApp Business Auto-Responder (Shanaya AI Persona)
Created for Android Studio using Kotlin.

## Overview
This app intercepts incoming notifications strictly for WhatsApp Business (`com.whatsapp.w4b`), extracts message text, queries Google Gemini 2.5 API with Shanaya AI persona using OkHttp, and sends replies directly in the background using Android `RemoteInput`.

## Features
- **Strict Package Filtering:** Only intercepts `com.whatsapp.w4b`
- **Data Extraction:** Extracts sender name and chat message cleanly
- **Anti-Loop Deduplication:** Automatically discards self-echo notifications to prevent infinite reply loops
- **Shanaya Persona:** "You are Shanaya, the real human female personal assistant of OG.SAHIL. Reply ONLY in short, natural Hinglish."
- **OkHttp + Coroutines:** Ultra-fast async execution
- **RemoteInput Background Dispatch:** Replies without waking the phone screen or opening WhatsApp

## Quick Setup in Android Studio
1. Open this unzipped folder in **Android Studio**.
2. Wait for Gradle sync to complete.
3. Connect your Android phone or start an emulator with Google Play services.
4. Run the app (`Shift + F10`).
5. Open the app on the phone:
   - Tap **"Grant Notification Access"** and toggle ON for this app.
   - Enter your **Google Gemini API Key** and tap Save.
   - Ensure the toggle is **Active**.
6. Send a WhatsApp Business message from another device to test!
