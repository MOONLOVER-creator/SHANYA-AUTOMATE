package com.sahil.autoreply

import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.switchmaterial.SwitchMaterial
import com.google.android.material.textfield.TextInputEditText
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * MainActivity
 *
 * User dashboard providing:
 * - One-tap direct deep link to Android Notification Listener Access settings.
 * - Gemini API Key secure storage.
 * - Master ON/OFF toggle switch for Shanaya auto-responder.
 * - Live recycler view log of intercepted WhatsApp Business messages and sent replies.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var statusCard: MaterialCardView
    private lateinit var tvPermissionStatus: TextView
    private lateinit var btnGrantPermission: MaterialButton
    private lateinit var switchActive: SwitchMaterial
    private lateinit var etApiKey: TextInputEditText
    private lateinit var btnSaveKey: MaterialButton
    private lateinit var rvLogs: RecyclerView
    private lateinit var tvEmptyLogs: TextView

    private val logItems = mutableListOf<LogEntry>()
    private lateinit var logAdapter: LogAdapter

    private val logReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == WhatsAppNotificationListenerService.ACTION_LOG_UPDATE) {
                val sender = intent.getStringExtra(WhatsAppNotificationListenerService.EXTRA_LOG_SENDER) ?: "Unknown"
                val message = intent.getStringExtra(WhatsAppNotificationListenerService.EXTRA_LOG_MESSAGE) ?: ""
                val reply = intent.getStringExtra(WhatsAppNotificationListenerService.EXTRA_LOG_REPLY) ?: ""
                val status = intent.getStringExtra(WhatsAppNotificationListenerService.EXTRA_LOG_STATUS) ?: "INFO"

                val entry = LogEntry(
                    sender = sender,
                    message = message,
                    reply = reply,
                    status = status,
                    timestamp = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
                )
                
                runOnUiThread {
                    logItems.add(0, entry)
                    logAdapter.notifyItemInserted(0)
                    rvLogs.scrollToPosition(0)
                    tvEmptyLogs.visibility = View.GONE
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initViews()
        setupListeners()
        loadSavedPreferences()
        setupRecyclerView()
    }

    private fun initViews() {
        statusCard = findViewById(R.id.statusCard)
        tvPermissionStatus = findViewById(R.id.tvPermissionStatus)
        btnGrantPermission = findViewById(R.id.btnGrantPermission)
        switchActive = findViewById(R.id.switchActive)
        etApiKey = findViewById(R.id.etApiKey)
        btnSaveKey = findViewById(R.id.btnSaveKey)
        rvLogs = findViewById(R.id.rvLogs)
        tvEmptyLogs = findViewById(R.id.tvEmptyLogs)
    }

    private fun setupListeners() {
        btnGrantPermission.setOnClickListener {
            // Direct user to Android Special App Access -> Notification Access screen
            val intent = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
            startActivity(intent)
        }

        btnSaveKey.setOnClickListener {
            val key = etApiKey.text?.toString()?.trim() ?: ""
            if (key.isNotEmpty()) {
                val prefs = getSharedPreferences("auto_reply_prefs", Context.MODE_PRIVATE)
                prefs.edit().putString("gemini_api_key", key).apply()
                Toast.makeText(this, "Gemini API Key saved successfully!", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Please enter a valid API Key", Toast.LENGTH_SHORT).show()
            }
        }

        switchActive.setOnCheckedChangeListener { _, isChecked ->
            val prefs = getSharedPreferences("auto_reply_prefs", Context.MODE_PRIVATE)
            prefs.edit().putBoolean("is_active", isChecked).apply()
            val text = if (isChecked) "Auto-Responder Activated!" else "Auto-Responder Paused"
            Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
        }
    }

    private fun loadSavedPreferences() {
        val prefs = getSharedPreferences("auto_reply_prefs", Context.MODE_PRIVATE)
        val apiKey = prefs.getString("gemini_api_key", "")
        val isActive = prefs.getBoolean("is_active", true)

        etApiKey.setText(apiKey)
        switchActive.isChecked = isActive
    }

    private fun setupRecyclerView() {
        logAdapter = LogAdapter(logItems)
        rvLogs.layoutManager = LinearLayoutManager(this)
        rvLogs.adapter = logAdapter
    }

    override fun onResume() {
        super.onResume()
        checkNotificationPermission()

        val filter = IntentFilter(WhatsAppNotificationListenerService.ACTION_LOG_UPDATE)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(logReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(logReceiver, filter)
        }
    }

    override fun onPause() {
        super.onPause()
        try {
            unregisterReceiver(logReceiver)
        } catch (_: Exception) {}
    }

    /**
     * Checks if user has enabled NotificationListenerService permission in Android Settings.
     */
    private fun checkNotificationPermission() {
        val isGranted = isNotificationServiceEnabled()
        if (isGranted) {
            tvPermissionStatus.text = "Permission Granted: Active & Listening"
            tvPermissionStatus.setTextColor(ContextCompat.getColor(this, android.R.color.holo_green_dark))
            btnGrantPermission.visibility = View.GONE
        } else {
            tvPermissionStatus.text = "Action Required: Enable Notification Access"
            tvPermissionStatus.setTextColor(ContextCompat.getColor(this, android.R.color.holo_red_dark))
            btnGrantPermission.visibility = View.VISIBLE
        }
    }

    private fun isNotificationServiceEnabled(): Boolean {
        val pkgName = packageName
        val flat = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
        if (!TextUtils.isEmpty(flat)) {
            val names = flat.split(":".toRegex()).toTypedArray()
            for (name in names) {
                val cn = ComponentName.unflattenFromString(name)
                if (cn != null && TextUtils.equals(pkgName, cn.packageName)) {
                    return true
                }
            }
        }
        return false
    }

    // Recycler View Adapter for Live Log entries
    data class LogEntry(
        val sender: String,
        val message: String,
        val reply: String,
        val status: String,
        val timestamp: String
    )

    class LogAdapter(private val items: List<LogEntry>) : RecyclerView.Adapter<LogAdapter.LogViewHolder>() {

        class LogViewHolder(view: View) : RecyclerView.ViewHolder(view) {
            val tvHeader: TextView = view.findViewById(R.id.tvLogHeader)
            val tvIncoming: TextView = view.findViewById(R.id.tvLogIncoming)
            val tvReply: TextView = view.findViewById(R.id.tvLogReply)
            val tvStatus: TextView = view.findViewById(R.id.tvLogStatus)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LogViewHolder {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.item_log, parent, false)
            return LogViewHolder(view)
        }

        override fun onBindViewHolder(holder: LogViewHolder, position: Int) {
            val item = items[position]
            holder.tvHeader.text = "${item.sender} • ${item.timestamp}"
            holder.tvIncoming.text = "Incoming: ${item.message}"
            holder.tvReply.text = "Shanaya: ${item.reply}"
            holder.tvStatus.text = item.status
            
            val color = when (item.status) {
                "SENT_SUCCESS" -> android.R.color.holo_green_dark
                "PROCESSING" -> android.R.color.holo_orange_dark
                else -> android.R.color.holo_red_dark
            }
            holder.tvStatus.setTextColor(ContextCompat.getColor(holder.itemView.context, color))
        }

        override fun getItemCount(): Int = items.size
    }
}
