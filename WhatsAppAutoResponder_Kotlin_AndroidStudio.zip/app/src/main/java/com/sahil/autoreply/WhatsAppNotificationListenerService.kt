package com.sahil.autoreply

import android.app.Notification
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap

/**
 * WhatsAppNotificationListenerService
 *
 * Requirements satisfied:
 * 1. Extends NotificationListenerService to intercept incoming notifications.
 * 2. Filters strictly for WhatsApp Business (package: "com.whatsapp.w4b").
 * 3. Extracts sender name and message text from notification extras.
 * 4. Calls Gemini API with Shanaya persona using OkHttp.
 * 5. Uses RemoteInput & Action PendingIntent to reply directly in background.
 * 6. Implements anti-loop deduplication to prevent auto-replying repeatedly.
 */
class WhatsAppNotificationListenerService : NotificationListenerService() {

    companion object {
        private const val TAG = "WhatsAppAutoReply"
        
        // Target WhatsApp Business package name
        const val TARGET_PACKAGE = "com.whatsapp.w4b"
        
        // Broadcast action to update UI activity log
        const val ACTION_LOG_UPDATE = "com.sahil.autoreply.LOG_UPDATE"
        const val EXTRA_LOG_SENDER = "sender"
        const val EXTRA_LOG_MESSAGE = "message"
        const val EXTRA_LOG_REPLY = "reply"
        const val EXTRA_LOG_STATUS = "status"

        // Cache to prevent duplicate replies to the same message
        // Maps "sender:message" -> timestamp
        private val processedMessages = ConcurrentHashMap<String, Long>()
        private const val DEDUPLICATION_WINDOW_MS = 60_000L // 60 seconds
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var geminiClient: GeminiClient

    override fun onCreate() {
        super.onCreate()
        geminiClient = GeminiClient(applicationContext)
        Log.i(TAG, "WhatsAppNotificationListenerService created and ready.")
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        Log.i(TAG, "WhatsAppNotificationListenerService destroyed.")
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        if (sbn == null) return

        val packageName = sbn.packageName
        
        // 1. Strict filtering: ONLY listen to WhatsApp Business
        if (packageName != TARGET_PACKAGE) {
            return
        }

        val notification = sbn.notification ?: return
        val extras = notification.extras ?: return

        // 2. Ignore group summary headers (e.g., "5 new messages")
        val isGroupSummary = (notification.flags and Notification.FLAG_GROUP_SUMMARY) != 0
        if (isGroupSummary) {
            Log.d(TAG, "Ignored group summary notification from $packageName")
            return
        }

        // 3. Extract sender name
        val sender = extras.getString(Notification.EXTRA_TITLE)
            ?: extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()
            ?: "Customer"

        // 4. Extract message text
        // WhatsApp messages often contain EXTRA_BIG_TEXT or EXTRA_TEXT_LINES
        var messageText = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()
        val textLines = extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)
        if (!textLines.isNullOrEmpty()) {
            // Get latest incoming line
            val lastLine = textLines.lastOrNull()?.toString()
            if (!lastLine.isNullOrBlank()) {
                messageText = lastLine
            }
        }

        if (messageText.isNullOrBlank()) {
            Log.d(TAG, "Message text is empty or media file notification from $sender. Skipping.")
            return
        }

        // 5. Anti-Loop Deduplication Check:
        // WhatsApp updates notification when reply is sent; ignore if we just replied to this message
        val messageKey = "$sender:$messageText"
        val currentTime = System.currentTimeMillis()
        val lastProcessed = processedMessages[messageKey]
        
        if (lastProcessed != null && (currentTime - lastProcessed) < DEDUPLICATION_WINDOW_MS) {
            Log.d(TAG, "Message already processed recently. Skipping to avoid loop: '$messageText'")
            return
        }
        processedMessages[messageKey] = currentTime

        // Clean up old cached items
        cleanOldProcessedMessages(currentTime)

        Log.i(TAG, "Incoming WhatsApp Business message from [$sender]: '$messageText'")

        // 6. Locate RemoteInput Quick Reply Action in Notification
        val quickReplyAction = findQuickReplyAction(notification)
        if (quickReplyAction == null) {
            Log.w(TAG, "No Direct Reply Action / RemoteInput found on notification from $sender")
            broadcastLog(sender, messageText, "No Reply Action found in notification", "FAILED")
            return
        }

        val remoteInput = quickReplyAction.remoteInputs?.firstOrNull()
        if (remoteInput == null) {
            Log.w(TAG, "Quick reply action found but RemoteInput is missing.")
            return
        }

        // 7. Check if Auto-Responder toggle is enabled in settings
        val prefs = applicationContext.getSharedPreferences("auto_reply_prefs", Context.MODE_PRIVATE)
        val isServiceActive = prefs.getBoolean("is_active", true)
        if (!isServiceActive) {
            Log.d(TAG, "Auto-responder is toggled OFF by user in app settings.")
            return
        }

        // 8. Generate reply via Gemini using Shanaya Persona in background thread
        serviceScope.launch {
            try {
                broadcastLog(sender, messageText, "Asking Shanaya (Gemini AI)...", "PROCESSING")
                
                val aiReply = geminiClient.generateShanayaReply(sender = sender, userMessage = messageText)
                
                if (aiReply.isNotBlank()) {
                    Log.i(TAG, "Shanaya Reply Generated: '$aiReply'")
                    
                    // 9. Send the reply directly via RemoteInput
                    val success = sendReplyDirectly(quickReplyAction, remoteInput, aiReply)
                    if (success) {
                        Log.i(TAG, "Auto-reply sent successfully to $sender via WhatsApp Business!")
                        broadcastLog(sender, messageText, aiReply, "SENT_SUCCESS")
                    } else {
                        Log.e(TAG, "Failed to dispatch RemoteInput reply to $sender")
                        broadcastLog(sender, messageText, "Failed to send RemoteInput", "FAILED")
                    }
                } else {
                    Log.w(TAG, "Gemini returned empty reply.")
                    broadcastLog(sender, messageText, "Empty reply from AI", "FAILED")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error processing AI auto-reply: ${e.message}", e)
                broadcastLog(sender, messageText, "Error: ${e.localizedMessage}", "ERROR")
            }
        }
    }

    /**
     * Inspects notification actions to locate the Direct Reply action containing RemoteInput.
     * Searches both standard notification actions and WearableExtender actions.
     */
    private fun findQuickReplyAction(notification: Notification): NotificationCompat.Action? {
        val actions = NotificationCompat.getActionCount(notification)
        for (i in 0 until actions) {
            val action = NotificationCompat.getAction(notification, i)
            if (action?.remoteInputs != null && action.remoteInputs!!.isNotEmpty()) {
                return action
            }
        }

        // Fallback: check WearableExtender actions if standard actions didn't have RemoteInput
        val wearableExtender = NotificationCompat.WearableExtender(notification)
        for (action in wearableExtender.actions) {
            if (action.remoteInputs != null && action.remoteInputs!!.isNotEmpty()) {
                return action
            }
        }

        return null
    }

    /**
     * Encapsulates reply text into RemoteInput bundle and sends the PendingIntent.
     */
    private fun sendReplyDirectly(
        action: NotificationCompat.Action,
        remoteInput: androidx.core.app.RemoteInput,
        replyText: String
    ): Boolean {
        return try {
            val intent = Intent()
            val bundle = Bundle()
            
            // Map reply text to the expected RemoteInput result key
            bundle.putCharSequence(remoteInput.resultKey, replyText)
            
            val nativeRemoteInput = android.app.RemoteInput.Builder(remoteInput.resultKey)
                .setLabel(remoteInput.label)
                .setChoices(remoteInput.choices)
                .setAllowFreeFormInput(remoteInput.allowFreeFormInput)
                .addExtras(remoteInput.extras)
                .build()

            RemoteInput.addResultsToIntent(
                arrayOf(nativeRemoteInput),
                intent,
                bundle
            )

            // Dispatch directly through the action's PendingIntent without opening WhatsApp
            action.actionIntent.send(applicationContext, 0, intent)
            true
        } catch (e: PendingIntent.CanceledException) {
            Log.e(TAG, "PendingIntent was canceled: ${e.message}")
            false
        } catch (e: Exception) {
            Log.e(TAG, "Error dispatching RemoteInput: ${e.message}", e)
            false
        }
    }

    private fun cleanOldProcessedMessages(now: Long) {
        val iterator = processedMessages.entries.iterator()
        while (iterator.hasNext()) {
            val entry = iterator.next()
            if (now - entry.value > DEDUPLICATION_WINDOW_MS) {
                iterator.remove()
            }
        }
    }

    private fun broadcastLog(sender: String, message: String, reply: String, status: String) {
        val intent = Intent(ACTION_LOG_UPDATE).apply {
            putExtra(EXTRA_LOG_SENDER, sender)
            putExtra(EXTRA_LOG_MESSAGE, message)
            putExtra(EXTRA_LOG_REPLY, reply)
            putExtra(EXTRA_LOG_STATUS, status)
            setPackage(packageName)
        }
        sendBroadcast(intent)
    }
}
