package com.sahil.autoreply

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * GeminiClient
 *
 * Implements Gemini REST API integration using OkHttp.
 * Encapsulates the Shanaya persona system instruction.
 */
class GeminiClient(private val context: Context) {

    companion object {
        private const val TAG = "GeminiClient"
        
        // Using Google Gemini 2.5 Flash model for ultra-fast response times
        private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent"
        
        // Exact system instruction required by the prompt
        const val SYSTEM_INSTRUCTION = "You are Shanaya, the real human female personal assistant of OG.SAHIL. Reply ONLY in short, natural Hinglish."
    }

    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    /**
     * Retrieves Gemini API Key from SharedPreferences.
     * In production, users enter this in MainActivity settings.
     */
    private fun getApiKey(): String {
        val prefs = context.getSharedPreferences("auto_reply_prefs", Context.MODE_PRIVATE)
        return prefs.getString("gemini_api_key", "") ?: ""
    }

    /**
     * Sends the WhatsApp message to Gemini and returns Shanaya's natural Hinglish reply.
     *
     * @param sender Name of the WhatsApp contact
     * @param userMessage Incoming message content
     * @return AI-generated text or a fallback polite message
     */
    suspend fun generateShanayaReply(sender: String, userMessage: String): String = withContext(Dispatchers.IO) {
        val apiKey = getApiKey()
        if (apiKey.isBlank()) {
            Log.w(TAG, "Gemini API Key is not set in app settings! Using polite fallback.")
            return@withContext "Haanji, message mil gaya hai. Sahil abhi busy hain, main Shanaya unko update kar dungi."
        }

        val requestUrl = "$BASE_URL?key=$apiKey"

        try {
            // Build the JSON payload for Gemini API
            val payload = buildGeminiPayload(userMessage)
            val mediaType = "application/json; charset=utf-8".toMediaType()
            val requestBody = payload.toString().toRequestBody(mediaType)

            val request = Request.Builder()
                .url(requestUrl)
                .post(requestBody)
                .header("Content-Type", "application/json")
                .build()

            val response = httpClient.newCall(request).execute()
            val responseBody = response.body?.string()

            if (!response.isSuccessful || responseBody == null) {
                Log.e(TAG, "Gemini API HTTP Error ${response.code}: $responseBody")
                return@withContext "Haanji, message mil gaya hai. Sahil abhi meeting me hain, main Shanaya unhe bata dungi."
            }

            // Extract reply text from Gemini JSON response
            val replyText = parseGeminiResponse(responseBody)
            return@withContext replyText.ifBlank {
                "Haanji, message mil gaya hai. Sahil abhi busy hain, main Shanaya unse baat karwati hoon."
            }

        } catch (e: IOException) {
            Log.e(TAG, "Network timeout or connection error: ${e.message}", e)
            return@withContext "Haanji, message note kar liya hai. Sahil thodi der me revert karenge."
        } catch (e: Exception) {
            Log.e(TAG, "Unexpected error in GeminiClient: ${e.message}", e)
            return@withContext "Haanji, message mil gaya hai. Sahil ko inform kar diya jayega."
        }
    }

    /**
     * Constructs Gemini REST API JSON structure:
     * {
     *   "system_instruction": { "parts": [{ "text": "..." }] },
     *   "contents": [{ "role": "user", "parts": [{ "text": "..." }] }],
     *   "generationConfig": { "temperature": 0.7, "maxOutputTokens": 120 }
     * }
     */
    private fun buildGeminiPayload(userMessage: String): JSONObject {
        val root = JSONObject()

        // System Instruction: Shanaya persona
        val systemInstructionObj = JSONObject()
        val systemPartsArray = JSONArray().apply {
            put(JSONObject().put("text", SYSTEM_INSTRUCTION))
        }
        systemInstructionObj.put("parts", systemPartsArray)
        root.put("system_instruction", systemInstructionObj)

        // Contents: User message with requested prompt wrapper
        val contentsArray = JSONArray()
        val userContentObj = JSONObject()
        userContentObj.put("role", "user")

        val partsArray = JSONArray().apply {
            put(JSONObject().put("text", "User message: $userMessage"))
        }
        userContentObj.put("parts", partsArray)
        contentsArray.put(userContentObj)
        root.put("contents", contentsArray)

        // Generation config for crisp Hinglish chat replies
        val generationConfig = JSONObject().apply {
            put("temperature", 0.7)
            put("maxOutputTokens", 150)
            put("topP", 0.95)
        }
        root.put("generationConfig", generationConfig)

        return root
    }

    /**
     * Parses the response:
     * candidates[0].content.parts[0].text
     */
    private fun parseGeminiResponse(jsonString: String): String {
        return try {
            val json = JSONObject(jsonString)
            val candidates = json.optJSONArray("candidates") ?: return ""
            if (candidates.length() == 0) return ""

            val firstCandidate = candidates.getJSONObject(0)
            val content = firstCandidate.optJSONObject("content") ?: return ""
            val parts = content.optJSONArray("parts") ?: return ""
            if (parts.length() == 0) return ""

            val text = parts.getJSONObject(0).optString("text", "")
            text.trim()
        } catch (e: Exception) {
            Log.e(TAG, "JSON parsing error: ${e.message}", e)
            ""
        }
    }
}
